<?php
include '../../settings.php';

$con = mysqli_connect($dbServer,$dbUser,$dbPass,$dbName);

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = mysqli_real_escape_string($con,$_POST['search']['value']); // Search value

## Search 
$searchQuery = " ";
if($searchValue != ''){
  $searchQuery = " and (id like '%".$searchValue."%' or username like '%".$searchValue."%'  ) ";
}

## Total number of records without filtering
$sel = mysqli_query($con,"select count(*) as allcount from users");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of record with filtering
$sel = mysqli_query($con,"select count(*) as allcount from users WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from users WHERE 1  $searchQuery order by $columnName $columnSortOrder limit $row,$rowperpage ";
$empRecords = mysqli_query($con, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
    $id = $row["id"];
    $encoded_id = base64_encode($id);
    $key = hash("SHA512",$encoded_id);
   
   $data[] = array( 
      "id"=>$row['id'],
      "username"=>$row['username'].'<br><font color="#0101DF"><small>'.$row['user_ip'].'</small></font>',
      "password"=>$row['password'],
      "coins"=>$row['coins'],
      "device"=>$row['mobile_mod'].'<br>'.$row['android_v'],
      "special_access"=>$row['special_access'],
      "can_share"=>$row['can_share'],
      "action" => '<a href="index.php?reset='.$row['id'].'" class="btn btn-sm btn-danger">Reset Device</a>
      <a href="search_history.php?id='.$row['id'].'" class=""</a>
      <a href="edit.php?reference='.$encoded_id.'&key='.$key.'&type=edit" class="btn btn-sm btn-success">Edit</a>'
   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);

echo json_encode($response);
?>