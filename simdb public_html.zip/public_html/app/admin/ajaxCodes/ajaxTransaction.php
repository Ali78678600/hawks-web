<?php
include '../settings.php';
require "../functions.php";
$con = mysqli_connect($dbServer,$dbUser,$dnPass,$dbName);

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue =  mysqli_real_escape_string($con,$_POST['search']['value']); // Search value

## Search 
$searchQuery = " ";
if($searchValue != ''){
//   $searchQuery = " and (from_user like '%".$searchId."%' or to_user like '%".$searchId."%'  ) ";
}

## Total number of records without filtering
$sel = mysqli_query($con,"select count(*) as allcount from transaction_history");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of record with filtering
$sel = mysqli_query($con,"select count(*) as allcount from transaction_history  WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from transaction_history WHERE 1 $searchQuery limit $row,$rowperpage ";
$empRecords = mysqli_query($con, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
 $from_user = getUsername($con, $row["from_user"] );
    $to_user = getUsername($con, $row["to_user"] );
     $time = date("H:i, d M Y",strtotime($row["sent_time"]));
   $data[] = array( 
      "from_user"=>$from_user,
      "to_user"=> $to_user,
      "coins"=> $row["coins"],
      "time"=> $time,
   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);

echo json_encode($response);
?>