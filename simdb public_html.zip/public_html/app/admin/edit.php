<?php
session_start();
include '../settings.php';
require "functions.php";

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["adminloggedin"]) || $_SESSION["adminloggedin"] !== true){
    header("location: login.php");
    exit;
}

if(!isset($_GET["reference"],$_GET["key"],$_GET["type"]) || ($_GET["type"] != "edit"))
{
    header("Location:index.php");
    exit;
}
$conn = mysqli_connect($dbServer,$dbUser,$dbPass,$dbName);

$decoded_id = base64_decode($_GET["reference"]);
$username = getUserValues($conn, $decoded_id, $table = "users",$column = "username");
$password = getUserValues($conn, $decoded_id, $table = "users",$column = "password");
$special_access = getUserValues($conn, $decoded_id, $table = "users",$column = "special_access");
$share_coins = getUserValues($conn,$decoded_id, $table = "users", $column = "can_share");
$message = getUserValues($conn,$decoded_id, $table = "users", $column = "message");

if($special_access == "1")
{
    $specialDropdownValues = '
     <option value="1" selected>True</option>
    <option value="0" >False</option>
    ';
}else
{
     $specialDropdownValues = '
     <option value="1">True</option>
    <option value="0" selected>False</option>
    ';
}

if($share_coins == "yes")
{
    $shareDropdownValues = '
     <option value="yes" selected>Yes</option>
    <option value="no" >No</option>
    ';
}else
{
     $shareDropdownValues = '
     <option value="yes">Yes</option>
    <option value="no" selected>No</option>
    ';
}

if(isset($_POST["delete"]))
{
    if(deleteUser($conn,$decoded_id) == true)
    {
        header("Location: index.php");
        exit;
    }
}

if(isset($_POST["edit"]))
{
    unset($_POST["edit"],$_POST["id"]);
    if(saveUserDetails($conn,$decoded_id,$_POST) === true)
    {
        header('Location: index.php');
        exit;
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
  
   
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 mt-4">
            <h2>Edit Page</h2>
                <?php 
                if(!empty($error)){
                    echo '<div class="alert alert-danger">' . $error . '</div>';
                }        
                ?>
        
                <form action="" method="post" >
                    <div class="form-group">
                        <label>ID</label>
                        <input type="text" name="id" class="form-control" value="<?= $decoded_id ; ?>" readonly>
                        
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="<?= $username; ?>">
                        
                    </div>    
                    <div class="form-group">
                        <label>Password</label>
                        <input type="text" name="password" class="form-control" value="<?= $password; ?>" />
                    </div>
                    <div class="form-group">
                        <label>Add Coins</label>
                        <input type="text" name="coins" class="form-control" value="<?= $coins; ?>">
                        
                    </div>    
                    <div class="form-group">
                        <label>Special Access</label>
                        <select class="form-control" name="special_access">
                            <?= $specialDropdownValues; ?>
                            
                        </select>
                    </div>
                     <div class="form-group">
                        <label>Can Share Coins?</label>
                        <select class="form-control" name="can_share">
                            <?= $shareDropdownValues; ?>
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <textarea row=2 name="message" placholder="Type Individual User message (if any)" class="form-control"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <input type="submit" name="edit" class="btn btn-sm btn-success" value="Save Changes">
                        <input type="submit" name="delete" class="btn btn-sm btn-danger" value="Delete">
                        <a href="index.php" class="btn btn-sm btn-outline-secondary" >Cancel</a>
                    </div>
                    
                </form>
        </div>
    </div>
</div>
    
</body>
</html>