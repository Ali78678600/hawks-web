<?php
include '../settings.php';
function login($conn)
{
    $username = $password = "";
        // Check if username is empty
        if(empty(trim($_POST["username"]))){
            return "Please enter username.";
        } else{
            $username = trim($_POST["username"]);
        }
        
        // Check if password is empty
        if(empty(trim($_POST["password"]))){
            return "Please enter your password.";
        } else{
            $password = trim($_POST["password"]);
        }
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM `admin` WHERE `username` = ?";
        
        if($stmt = mysqli_prepare($conn, $sql))
        {
            // Bind variables to the prepared statement as parameters
              mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt))
            {
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1)
                {                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $db_password);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if($password == $db_password)
                        {
                            // Password is correct, so start a new session
                            // Store data in session variables
                            $_SESSION["adminloggedin"] = true;
                            $_SESSION["adminId"] = $id;
                            $_SESSION["admin"] = $username;
                            // Redirect user to welcome page
                            header("location: index.php");
                            exit;
                        } else
                        {
                            // Password is not valid, display a generic error message
                            return "Invalid username or password.";
                        }
                    }
                } else
                {
                    // Username doesn't exist, display a generic error message
                    return  "Invalid username or password.";
                }
            } else{
               return "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
        
    
    
    // Close connection
    mysqli_close($link);
}

function showAllUsers($conn , $limit_start, $limit_end)
{
    $arr = array();
    $query = mysqli_query($conn, "SELECT * FROM `users` order by `coins` desc LIMIT $limit_start, $limit_end ");
    if(mysqli_num_rows($query) > 0)
    {
        while($row = mysqli_fetch_assoc($query))
        {
            unset($row["message"]);
            array_push($arr,$row);
        }
        return json_encode($arr);
    }else
    {
        return false;
    }
}

function getTotalUsers($conn)
{
    $query = mysqli_query($conn, "SELECT * FROM `users`");
    if(mysqli_num_rows($query) > 0)
    {
        return mysqli_num_rows($query);
    }else
    {
        return false;
    }
}


function showCanShareCoinsUser($conn)
{
    $arr = array();
    $query = mysqli_query($conn, "SELECT * FROM `users` where `can_share`='yes' order by `coins` desc");
    if(mysqli_num_rows($query) > 0)
    {
        while($row = mysqli_fetch_assoc($query))
        {
            unset($row["message"]);
            array_push($arr,$row);
        }
        return json_encode($arr);
    }else
    {
        return false;
    }
}
function showSpecialAccessUsers($conn)
{
    $arr = array();
    $query = mysqli_query($conn, "SELECT * FROM `users` where `special_access`='1' order by `coins` desc");
    if(mysqli_num_rows($query) > 0)
    {
        while($row = mysqli_fetch_assoc($query))
        {
            unset($row["message"]);
            array_push($arr,$row);
        }
        return json_encode($arr);
    }
}

function getColumnNames($conn,$tableName,$unsetColumns = array())
{
    $arr = array();
    $query = mysqli_query($conn, "SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`=$dbName AND `TABLE_NAME`='$tableName' ;");
    if(mysqli_num_rows($query) > 0)
    { 
        while($row = mysqli_fetch_assoc($query))
        {
            for($i = 0; $i< count($unsetColumns);$i++)
            {
                if (($key = array_search($unsetColumns[$i], $row)) !== false) 
                {
                    unset($row[$key]);
                }
            }
                 array_push($arr,$row);
                 unset($row);
        }
        return $arr;
    }
}

function getUserValues($conn,$userid,$table,$column)
{
    $val = "";
    $query = mysqli_query($conn, "SELECT * FROM `$table` WHERE `id`='$userid' ");
    if(mysqli_num_rows($query) > 0)
    {
        while($row = mysqli_fetch_assoc($query))
        {
            $val = htmlentities($row[$column]);
        }
        return $val;
    }
}

function deleteUser($conn,$userid)
{
    $query = mysqli_query($conn, "DELETE FROM `users` WHERE `id`='$userid' ");
    if($query)
    {
        return true;
    }else { return false; }
}

function saveUserDetails($conn,$userid,$values = array())
{
    $sql = 'UPDATE `users` SET ';
    foreach($values as $key => $val)
    {
        $sql .= " `$key` = '".htmlentities($val)."', ";
    }
    $sql = substr($sql, 0, -2);
    $sql .= " WHERE `id` = '$userid' ";
    $query = mysqli_query($conn,$sql);
    if($query)
    {
        return true;
    }else { return false; }
}


function getUsername($conn,$userid)
{
$result = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$userid' ");
     
    if(mysqli_num_rows($result) > 0 )
    {
        while($row =  mysqli_fetch_assoc($result))
        {
            $name =  htmlentities($row["username"]);
        }
        return $name;
    }else
    {
        return "Not Found";
    }
}


function showTransactions($conn , $limit_start, $limit_end)
{
    $result = mysqli_query($conn,"SELECT * FROM `transaction_history` WHERE  DATE(sent_time) >= DATE(NOW()) - INTERVAL 30 DAY LIMIT $limit_start, $limit_end ");
    if(mysqli_num_rows($result) > 0 )
    {
        while($row = mysqli_fetch_assoc($result))
        {
            $from_user = getUsername($conn, $row["from_user"] );
            $to_user = getUsername($conn, $row["to_user"] );
             $time = date("H:i, d M",strtotime($row["sent_time"]));
            $output .= '<tr>
              <td>'.$from_user.'</td>
              <td>'.$to_user.'</td>
              <td>'.$row["coins"].'</td>
              <td>'.$time.'</td>
            </tr>';
        }
        return $output;
    }else { return false; }
    
}

function getTotalTransactions($conn)
{
    $result = mysqli_query($conn,"SELECT * FROM `transaction_history` WHERE  DATE(sent_time) >= DATE(NOW()) - INTERVAL 30 DAY");
    if(mysqli_num_rows($result) > 0 )
    {
        return mysqli_num_rows($result);
    }else { return false; }
}

function showUserIPs($conn , $limit_start, $limit_end)
{
     $result = mysqli_query($conn,"SELECT * FROM `users` LIMIT  $limit_start, $limit_end ");
    if(mysqli_num_rows($result) > 0 )
    {
        while($row = mysqli_fetch_assoc($result))
        {
            $userid = $row["id"];
            $query1 = mysqli_query($conn,"SELECT * FROM `user_ip` WHERE `user_id`='$userid' ORDER BY `time` DESC ");
            if(mysqli_num_rows($query1) > 0)
            {
                $username = getUsername($conn, $row["id"] );
                $output .= '<tr>
                      <td>'.$row["id"].'</td>
                      <td>'.$username.'</td>
                    ';
                $ipOutput = $timeOutput = "";
                $i = 0;
                while($row1 = mysqli_fetch_assoc($query1))
                {
                    $time = date("H:i, d M",strtotime($row1["time"]));
                    if($i == 0)
                    {
                         $ipOutput .= '<div class="badge badge-pill badge-primary ml-2">'.$row1["ip_address"].' (Latest) </div>';
                        $timeOutput .= '<div class="badge  badge-pill badge-success ml-2">'.$time.'  (Latest) </div>';
                    }else
                    {
                         $ipOutput .= '<div class="badge badge-pill badge-primary ml-2">'.$row1["ip_address"].'</div>';
                        $timeOutput .= '<div class="badge badge-pill badge-success ml-2">'.$time.'</div>';
                    }
                    $i++;
                }  
                $output .= '
                      <td>'.$ipOutput.'</td>
                      <td>'.$timeOutput.'</td>
                    </tr>';
            }
        }
        return $output;
    }else { return false; }
}

function getValues($conn,$table,$col)
{
     $val = "";
    $query = mysqli_query($conn, "SELECT * FROM `$table` ");
    if(mysqli_num_rows($query) > 0)
    {
        while($row = mysqli_fetch_assoc($query))
        {
            $val = htmlentities($row[$col]);
        }
        return $val;
    }
}


function saveAnouncement($conn,$values = array())
{
    $sql = 'UPDATE `website` SET ';
    foreach($values as $key => $val)
    {
        $sql .= " `$key` = '".htmlentities($val)."', ";
    }
    $sql = substr($sql, 0, -2);
    $sql .= " WHERE `id` = '1' ";
    $query = mysqli_query($conn,$sql);
    if($query)
    {
        return true;
    }else { return false; }
}

?>