<?php
session_start();
include '../settings.php';
require "functions.php";
  
          
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["adminloggedin"]) || $_SESSION["adminloggedin"] !== true){
    header("location: login.php");
    exit;
}


$conn = mysqli_connect($dbServer,$dbUser,$dbPass,$dbName);

if(isset($_POST["special_access"]))
{
    $allUsers = json_decode(showSpecialAccessUsers($conn),true);
}

if(isset($_POST["can_share"]))
{
    $allUsers = json_decode(showCanShareCoinsUser($conn),true);
}


if(isset($_GET["reset"])){
$usID = $_GET["reset"];
$sql = "UPDATE users SET mobile_mod='None', android_v='None' WHERE id='$usID'";
if ($conn->query($sql) === TRUE) {
   $_SESSION["reset"] = 'Done';
   header("location: index.php");
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Users</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
 

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4-4.6.0/jq-3.3.1/dt-1.11.1/r-2.2.9/rr-1.2.8/sb-1.2.1/sp-1.4.0/sl-1.3.3/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4-4.6.0/jq-3.3.1/dt-1.11.1/r-2.2.9/rr-1.2.8/sb-1.2.1/sp-1.4.0/sl-1.3.3/datatables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>

</head>
<body>
    
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand bg-primary pl-2 pr-2 text-white" href="../addusera.php">Add New User</a>
      
    </div>
    <ul class="nav navbar-nav mt-2">
      <li class="btn btn-sm btn-danger"><a href="logout.php" style="text-decoration:none;color:white">Signout Account</a></li>
    </ul>
  </div>
</nav>

<div class="container-fluid mt-4">
    <div class="row justify-content-center"> 
        <div class="col-md-4">    
            <div class="form-group has-search">
                <span class="fa fa-search form-control-feedback"></span>
                <!--<input type="text" class="form-control" id="searchbar" placeholder="Search in table...">-->
             </div>
             <div class="form-group">
                 <form method="post" id="accessForm">
                 <!--<input type="checkbox" name="special_access" id="special_access" style="color:black" value="yes" <?php if(isset($_POST["special_access"])){echo "checked";} ?> /> -->
                 <!--   <label for="special_access">Show Special Access Members</label>-->
                </form>
             </div>
              <div class="form-group">
                 <form method="post" id="shareForm">
                 <!--<input type="checkbox" name="can_share" id="can_share" style="color:black" value="yes" <?php if(isset($_POST["can_share"])){echo "checked";} ?> /> -->
                 <!--   <label for="can_share">Show Users that can Share Coins</label>-->
                </form>
             </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <?php
            if(isset($_SESSION["reset"])){
             echo '<div class="alert alert-success" role="alert">
                      Device Setting has een successfully refreshed.
                    </div>';
                    unset($_SESSION["reset"]);
            }
            ?>
            <table class="table table-bordered text-center" id="UserTable">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">Username</th>
                  <th scope="col">Password</th>
                  <th scope="col">Coins</th>
                  <th scope="col">Device</th>
                  <th scope="col">Special Access</th>
                  <th scope="col">Can Share?</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody id="transactions_list">
                
              </tbody>
            </table>  
            <div id="pagination">
          
           
            </div>
        </div>
    </div>
</div>



<script>
$(document).ready(function(){

   $('#UserTable').DataTable({
      'processing': true,
      'order': [[3, "desc"]],
      'ordering': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':'ajaxCodes/ajaxIndex.php'
      },
      'columns': [
         { data: 'id'},
         { data: 'username' },
         { data: 'password' },
         { data: 'coins' },
         { data: 'device' },
         { data: 'special_access' },
         { data: 'can_share' },
         { data: 'action' },
         
      ],
     
   });
   
  
    $( "#special_access" ).change(function() {
        if($(this).is(":checked"))
        {
            $( "#accessForm" ).submit();
        }
        
    });
      $( "#can_share" ).change(function() {
        if($(this).is(":checked"))
        {
            $( "#shareForm" ).submit();
        }
        
    });
});
</script>

</body>
</html>