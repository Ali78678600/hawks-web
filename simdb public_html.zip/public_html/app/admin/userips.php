<?php
session_start();
include '../settings.php';
require "functions.php";

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["adminloggedin"]) || $_SESSION["adminloggedin"] !== true){
    header("location: login.php");
    exit;
}
$conn = mysqli_connect($dbServer,$dbUser,$dbPass,$dbName);

$results_per_page = 50; 
if (!isset ($_GET['page']) ) 
{  
    $page = 1;  
} else {  
    $page = $_GET['page'];  
}  
$page_first_result = ($page-1) * $results_per_page;  
$number_of_pages = ceil ( getTotalUsers($conn) / $results_per_page);

$allUserIps = showUserIPs($conn , $page_first_result, $results_per_page);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>User IP History</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>

<body>
  
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand bg-primary pl-2 pr-2 text-white" href="index.php">Person Trackers</a>|
          <a href="transactions.php">Transaction History</a> |
           <a href="userips.php">User IP List</a> |
          <a href="message.php">Announcement</a> |
          <a href="complaints.php">Complaints</a> 
    </div>
    <ul class="nav navbar-nav mt-2">
      <li class="btn btn-sm btn-danger"><a href="logout.php" style="text-decoration:none;color:white">Signout Account</a></li>
    </ul>
  </div>
</nav>


<div class="container-fluid">
    <div class="row justify-content-center"> 
        <div class="col-md-4">    
            <div class="form-group has-search">
                <span class="fa fa-search form-control-feedback"></span>
                <input type="text" class="form-control" id="searchbar" placeholder="Search in table...">
             </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <table class="table table-bordered text-center" style="overflow:scroll">
              <thead class="thead-dark">
                <tr>
                  <th scope="col" class="col-2">ID</th>
                  <th scope="col" class="col-2">Username</th>
                  <th scope="col" class="col-4">Ip Address</th>
                  <th scope="col" class="col-4">Login Time</th>
                </tr>
              </thead>
              <tbody id="ip_list">
                <?= $allUserIps; ?>
              </tbody>
            </table>  
             <div id="pagination">
                 <?php
                if( (!isset($_POST["can_share"])) && (!isset($_POST["special_access"])) )
                {
                  //display the link of the pages in URL  
                    for($page = 1; $page<= $number_of_pages; $page++) {  
                        echo '<a href = "userips.php?page=' . $page . '">' . $page . ' </a> | ';  
                    }  
                }
                  
                ?>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
  $("#searchbar").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#ip_list tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        $("#pagination").hide();
    });
  });
});
</script>

</body>
</html>
