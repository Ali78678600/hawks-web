<?php
session_start();
require_once 'config.php';
require "functions.php";
$error = '<div class="alert alert-primary" role="alert">
  This is a primary alert—check it out</div>';
$userID = $_SESSION["id"];

// Check if the user is logged in, if not then redirect him to login page
if( !isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login/index.php");
    exit;
}



if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}

if(isset($_POST["search"]))
{
    $num = $_POST["search"];
    $sql = "INSERT INTO search_log (number, user_id)
        VALUES ('$num', '$userID')";
        if ($link->query($sql) === TRUE) {}
    
    $output = fetchRecordUsingLink($conn,$_POST["search"]);
    $remainingCoins = getTotalCoins($conn);

}

$remainingCoins = getTotalCoins($conn);
$messageForUsers = getUserMessage($conn);
$public_message = publicMessage($conn);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Fake CNIC Maker</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 


   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
body {
 background-image: url("https://www.pngmagic.com/product_images/sky-blue-hd-background-image-for-banner.jpg");
 background-color: gray;
}
#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}
</style>
</head>
<a class="btn mt-3 btn-primary" href="http://newdata.tk/app/index.php" role="button">Back</a>
<body>

    <div>
        <br>







<div class="container col-md-6" id="cont">
 
    <div class="row d-flex justify-content-center" >
      <div class="col-md-12 ">


          


<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:black;
  }
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style> 
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>

<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
<!doctype html>
<html lang="en">
<head>
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8724024914762344"
     crossorigin="anonymous"></script>

<meta name="google-site-verification" content="nsKhq-GqLB_Ay07pnL3L_FmFFuQGETFJBmQSzSkvdj0" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link rel="stylesheet" href="utils.css">
<link rel="stylesheet" href="style.css">
</head>
<style>
    .row {
        margin: 10px !important;
    }
</style>
<body>
<nav class="navbar navbar-expand-lg bg-light">
<div class="container-fluid"><a class="navbar-brand"  height="42" />             <strong><em>༒☆ 𝐇𝐀𝐖𝐊'𝐒 𝐃𝐁☆༒               <br/>  03215948578/03181694126</em></strong>                </a>
<div class="collapse navbar-collapse" id="navbarSupportedContent">

</li>
</ul>
</div>
</div>
</nav>
<style>
.navbar{
    /* background-color: #fafcfe !important; */
    background-color: var(--main) !important;
    box-shadow: 0px -23px 40px #64a4e3;
    color: white;
}
.navbar li a{
    color: white;
}
.dropdown-menu a{
    color: black !important;
}
.dropdown-menu a:active{
    color: rgb(255, 255, 255) !important;
}
.navbar-toggler-icon {
/* background-image: url('/images/menu.png'); */
}

.navbar-nav .nav-link.active, .navbar-nav .show>.nav-link {
    color: white;
}

hr{
    margin: .1rem 0;
}

.card{
    width: 90%;
    margin: 20px auto;
}
h1{
    font-size: calc(1rem + 1vw);
    /* font-weight: bold; */
}
.cardheadings{
    background-color: var(--light);
}

.inputSearch{
    background-color: var(--red);
    border-radius: 10px;
    padding: 10px;
    width: 100%;
    border: 1px;
    border-style: solid;
    border-color: black; /* red */
}
.searchbtn{
    margin-top: 9px;
    width: 5rem;
}

.inputSearch:active{
    background-color: var(--red);
    border-radius: 10px;
    padding: 10px;
    width: 100%;
    /* border: 1px solid var(--border); */
}
.tool-img{
    width: 56px;
}
.tool-text{
    margin-top: 10px;
    font-size: calc(1.275rem + -0.7vw);
}
.tools{
    display: flex;
    flex-direction: column;
    justify-content: start;
}
.bottomContent{
    padding: 10px;
}
footer{
    background-color: var(--main);
    padding: 10px;
    margin: 10px 0px 0px 0px;
}
footer li{
    color: white;
}
footer a{
    color: white;
    text-decoration: none;
}
footer ul{
    padding-left: 1rem;
}
.bottomheadings{
color: var(--main);
font-size: 30px;
font-weight: 600;
}

.bottomsubheadings{
color: var(--main);
font-size: 24px;
font-weight: 500;
}


.row {
    display: flex;
    justify-content: start;
    /* align-items: center; */
    border-bottom: 1px solid var(--main);
    padding: 10px;
    
}


    
.detailshead {
    /* margin-left: 10px; */
    /* margin-left: 10px; */
    /* width: 70px; */
    font-weight: bolder;
    padding-right: 26px;
}

.resultcontainer {
    display: flex;
    flex-wrap: wrap;
    
    justify-content: center;

}

.container {
    width: 385px;
    padding: 10px;
    margin: 5px;
    /* border: 1px solid var(--borderColor); */
    animation-name: resultanim;
    animation-duration: .7s;
    animation-fill-mode: alternate;
    animation-iteration-count: 1;
    animation-timing-function: ease-in-out;
    position: relative;


}


/* Search Page */

.collapseable-btn{
    margin-top: 10px;
    width: 90%;
}
#cnic-top{
    font-size: 15px;
}
.all-nums{
    margin-top: 5px;
}
.simple-search{
    padding: 8px;
    border: 1px solid;
    border-radius: 5px;
}


/* License  */
.select-menu{
    margin-top: 9px;
}
.alert{
    margin-top: 9px;
}



.bill-img{
    width: 141px;
    margin-top: 10px;
}

.bill-card{
    width: 16rem; 
    padding: 12px;
    margin: 20px!important;
    /* box-shadow: 3px 19px 17px var(--shadow); */
}
@media screen and (max-width: 500px) {
    .tools-container{
       display: block!important;

        /* box-shadow: 3px 19px 17px var(--shadow); */
    } 
}

@media screen and (max-width: 600px) {
    .blog-card{
        width: 24rem; 
        padding: 12px;
        margin: -10px!important;

        /* box-shadow: 3px 19px 17px var(--shadow); */
    } 
}
.blog-card{
    width: 24rem; 
    padding: 12px;
    margin: 2px!important;

    /* box-shadow: 3px 19px 17px var(--shadow); */
}

.myblogpost{
    display: inline;
}
.blog-inner{
    width: 100%;
}
.main-blog-card{
    width: 99%;
}

.tools .card-body{
   transition: .3s;

     /* box-shadow: 3px 19px 17px var(--shadow); */
 } 
.tools .card-body:hover{
  background-color: var(--light);

  box-shadow: 3px 19px 17px var(--shadow);
 } 


@import url('https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&display=swap');


:root{
    --main:#0d6efd;
    --dark:#0a53be;
    --light:red;
    --border:#afcefc;
    --shadow:#a4a7ff45;
}

.m-auto{
    margin: auto;
}
.bold{
    font-weight: bold;
}
.bold-500{
    font-weight: 500;
}

.maincolor:hover{
    color: var(--main);
}

.maincolor{
    color: var(--main);
}
.black{
    color: black;
}

.f-primary{
    font-family: 'Nunito Sans', sans-serif;

}
body{
    font-family: 'Nunito Sans', sans-serif;
}
.color-danger{
    color:#dc3545 ;
}


h4 {
  background-color: yellow;
}
    .urduh {
 font-family: Jameel Noori Nastaleeq;
}
</style>
<div class="card " style="text-align: center;"><strong><em>The name of trust</em></strong></div>
<div class="card ">
<h1 class="card-header bg-dark text-white" style="text-align: center;"><em>All Premium Courses</em></h1>
<ol>
<li class="card-body"><em>LEARNING 💥✅*One of the Best Dropshipping course ❣</em></li>
 <a href="https://drive.google.com/drive/folders/1U1S2nNWFmm1OJ54yCFG_M78esXS6MBD-" class="w3-button w3-black">Download</a>
<li class="card-body"><em>♦️✨  *Hammad Kiyani Facebook instream ads* *course 100% working link*</em></li>
 <a href="https://mega.nz/folder/NtMQGRaY#qb1LeVDFlw26Fw9oFVDbEQ" class="w3-button w3-black">Download</a>
<li class="card-body"><em>```Xtream Commerce Urdu Courses```*</em></li>
 <a href="https://mega.nz/folder/vxUznQ7D#Bv5EVMFKsd-ZIqfypCQEXA" class="w3-button w3-black">Download</a>
<li class="card-body"><em>Shopify dropshipping</em></li>
 <a href="https://mega.nz/folder/fsN3WQbL#gO6oe3z2h1DFMjLbz4B82g" class="w3-button w3-black">Download</a>
<li class="card-body"><em>wordpress</em></li>
 <a href="https://mega.nz/folder/bp1WDKYD#DEy_7EgbtfDh-udLoQtD_g" class="w3-button w3-black">Download</a>
<li class="card-body"><em>SEO </em></li>
 <a href="https://mega.nz/folder/uwUhCCRR#Yet-bWYTCToIfhkgCum_8w" class="w3-button w3-black">Download</a>
<li class="card-body"><em>video editing</em></li>
 <a href="https://mega.nz/folder/qo822SwT#xuWlsw7MHBNAjtmb5AF7XQ" class="w3-button w3-black">Download</a>
<li class="card-body"><em>ios app development</em></li>
 <a href="https://mega.nz/folder/Tld1DSKb#PLZ5wnX0yoDjo04dX7afsg" class="w3-button w3-black">Download</a>
<li class="card-body"><em>google ads</em></li>
 <a href="https://mega.nz/folder/bo123ATb#6L16Tbc3z47O4KhsIXKkTQ" class="w3-button w3-black">Download</a>
<li class="card-body"><em>email marketing</em></li>
 <a href="https://mega.nz/folder/jxMjSSpI#hCByLH9Q56fBkzWfc8m0dw" class="w3-button w3-black">Download</a>
<li class="card-body"><em>daraz sellers </em></li>
 <a href="https://mega.nz/folder/WkMDxaRS#dOg35M0SSu530E6NpfTBoA" class="w3-button w3-black">Download</a>
<li class="card-body"><em>content writing</em></li>
 <a href="https://mega.nz/folder/zp1yyCqa#Me2EY_K3A2YPWShQ1QO4mg" class="w3-button w3-black">Download</a>
<li class="card-body"><em>android app development</em><em></em></li>
 <a href="https://mega.nz/folder/q1FHUaQa#yMN2iefEwc-F4bUEBPLkOQ" class="w3-button w3-black">Download</a>
<li><em>   facebook ads</em><em></em></li>
 <a href="https://drive.google.com/folderview?id=1DMAyUAmBylkE4ZemMbcHJYzNoD0WPgJD" class="w3-button w3-black">Download</a>
 <li class="card-body"><em>amazon affiliate marketing</em><em></em></li>
 <a href="https://mega.nz/folder/ThcHSQiA#sg3hEaulJWAIzGbq39Vjlw" class="w3-button w3-black">Download</a>
<li><em>   3d animation</em><em></em></li>
 <a href="https://mega.nz/folder/q1M1VSaL#gUQh3V-6FPK6EzVAfX4F7Q" class="w3-button w3-black">Download</a>
 <li class="card-body"><em>Ebay</em><em></em></li>
 <a href="https://mega.nz/folder/j9si0TLZ#4Z_PVRs_lp-F6t9aCHp__w" class="w3-button w3-black">Download</a>
<li><em>   instagram marketing</em><em></em></li>
 <a href="https://mega.nz/folder/S4kiVCBZ#7M5uPKD-KdGt0mghEIFWWw" class="w3-button w3-black">Download</a>
 <li class="card-body"><em>youtube marketing</em><em></em></li>
 <a href="https://mega.nz/folder/C4VkAZ6R#U5xoymtNJv0uAoC0x72yLQ" class="w3-button w3-black">Download</a>
<li><em>   Graphic Designing Course</em><em></em></li>
 <a href="https://mega.nz/folder/CwElWCba#T4kYRmEXTBE3_8NbO_OBcw" class="w3-button w3-black">Download</a>
 <li><em>  JazakAllah</em><em></em></li>
 <a href="https://mega.nz/folder/2i5UBRBR#_2tMyaqGD1L6Xl3fRdyhxw" class="w3-button w3-black">Download</a>
 <li class="card-body"><em>Kali Linux master class
 Red team Blueprint</em><em></em></li>
 <a href="https://mega.nz/folder/PYkhkIiZ#FI8Il1Jm2J0DqkOslkZZBQ" class="w3-button w3-black">Download</a>
<li><em>   *Make Your PC And Leptop Look Better* totally change 😍❤️🤝✅
Complete Method 😍</em><em></em></li>
 <a href="https://drive.google.com/drive/folders/1Mw_gRWJSlpPMUFlwoHR5xndnrkgSuep8" class="w3-button w3-black">Download</a>
 <li class="card-body"><em>*SEO Complete Course*

SEO kia hoti hy or kesy krni chaiye complete ✅</em><em></em></li>
 <a href="https://drive.google.com/drive/folders/1FMzdZMbVUZbsZMnedbzClt5OxW0R3zOW" class="w3-button w3-black">Download</a>

</ol>

<p><em></em></p>

</div>
</body>
</html>



</a> </h4>