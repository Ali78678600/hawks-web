<?php
$data   =   $_SERVER['HTTP_USER_AGENT'];
$data   =   str_replace(")",";",$data);
$data   =   str_replace("(",";",$data);

$user_ip    =   $_SERVER['REMOTE_ADDR'];

$pieces = explode(";", $data);
$android_v  =    $pieces[2];
$mobile_mod  =    $pieces[3];

$bcheck  = $pieces[6];
$bcheck   =   str_replace(" ","-",$bcheck);
$bpieces = explode("-", $bcheck);
$browser = $bpieces[1];

?>