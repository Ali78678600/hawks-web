<?php

include 'settings.php';
function checkUserIP($conn,$userid,$ip_address)
{
    if (filter_var($ip_address, FILTER_VALIDATE_IP)) 
    {
        $arr = array();
        $query = $conn->prepare("SELECT * FROM `user_ip` where `user_id` = :id ");
        $query->bindParam(':id',$userid,PDO::PARAM_INT);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
        if($results)
        {
            foreach ($results as $result) 
            {
            	 array_push($arr,$result["ip_address"]);
            }
        }
        if(in_array($ip_address,$arr))
        {
            return true;
        }else { return false; }
    }else { echo "Invalid IP Address"; }
}

//done
function insertUserIP($conn,$userid,$ip_address)
{
    if (filter_var($ip_address, FILTER_VALIDATE_IP)) 
    {
        $query = $conn->prepare("INSERT INTO `user_ip`(`user_id`,`ip_address`) VALUES(:userid,:ip) ");
        $query->bindParam(':userid',$userid,PDO::PARAM_INT);
        $query->bindParam(':ip',$ip_address,PDO::PARAM_INT);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
        if(mysqli_stmt_execute($results))
        {
            return true;
        }
    }else { echo "Invalid IP address"; }
}

// //done
function fetchRecord()
{
    $conn = new PDO("mysql:host=$dbServer;dbname=$dbName", $dbUser, $dbPas);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $arr = array();
    $opr = strtolower(substr($_POST["operator"], 0 , 1));
    $tables_query =  $conn->prepare("SELECT table_name FROM information_schema.tables WHERE table_schema = $dbName AND table_name LIKE CONCAT( '%', :opr, '%') ORDER BY table_name asc;");
    $tables_query->bindParam(':opr',$opr,PDO::PARAM_STR);
    $tables_query->execute();
    if($tables_query->rowCount() > 0)
    {
        $rows0 = $query->fetchAll(PDO::FETCH_ASSOC);
        if($rows0)
        {
            foreach ($rows0 as $row0) 
            {
            	$table_name =  $row0["table_name"];
                $number= trim($_POST["number"] , " " );
                if( strlen($number) == 10)
                {
                    $query = $conn->prepare("SELECT * FROM `$table_name` where `Mobile` = :num ");
                    $query->bindParam(':num',$number,PDO::PARAM_STR);
                    $query->execute();
                    if($query->rowCount() > 0)
                    {
                        $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
                        if($rows1)
                        {
                            foreach ($rows1 as $row1) 
                            {
                                array_push($row1, ucfirst($_POST["operator"]) );
                                array_push($arr , $row1);
                                unset($row1);
                            }
                        }
                        break;
                    }
                }else if(strlen($number) == 13)
                {
                    $query = $conn->prepare("SELECT * FROM `$table_name` where `Cnic` = :num ");
                    $query->bindParam(':num',$number,PDO::PARAM_STR);
                    $query->execute();
                    if($query->rowCount() > 0)
                    {
                        $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
                        if($rows1)
                        {
                            foreach ($rows1 as $row1) 
                            {
                                array_push($row1, ucfirst($_POST["operator"]) );
                                array_push($arr , $row1);
                                unset($row1);
                            }
                        }
                        continue;
                    }
                }else{ break;}
            }
        }
    }
    if( (getTotalCoins($conn) == 0) && (checkSpecialAccess($conn) == false) )
    {
        return '
        <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
    }
    else if( (checkSpecialAccess($conn) == true) || (getTotalCoins($conn) > 0) )
    {
        $output = '';
        if(count($arr) > 0)
        {
            for($i = 0;$i < count($arr);$i++)
            {
                $output .= '
                <tr style="background-color:blue;font-weight:bold;">
                <td><i>Mobile No</i></td>
                <td>'.$arr[$i]["Mobile"].'</td>
            </tr>
            <tr>
                <td><i>Name</i></td>
                <td>'.$arr[$i]["Name"].'</td>
            </tr>
            <tr>
                <td><i>CNIC</i></td>
                <td>'.$arr[$i]["CNIC"].'</td>
            </tr>
            <tr>
                <td><i>Address</i></td>
                <td>'.$arr[$i]["Address"].'</td>
            </tr>';        
            }
            return $output;
        }
    }
}

//done
function fetchRecordUsingLink($conn,$search)
{
        if( (getTotalCoins($conn) == 0) && (checkSpecialAccess($conn) == false) )
        {
            return '
            <tr><td class="bg-danger text-white" colspan=2>ACCOUNT NOT ACTIVE❌</td></tr>';
        }
        else if( (checkSpecialAccess($conn) == true) || (getTotalCoins($conn) > 0) )
        {
            $url = 'https://swifty.tk/api.php?search='.$search;
            $arr = json_decode(file_get_contents($url), true);
            $output = '';
            $numbers = array();
            for($i = 0;$i < count($arr); $i++)
            {
                if(in_array($arr[$i]["Mobile"] , $numbers))
                {
                    continue;
                }
                else
                {
                    array_push($numbers,$arr[$i]["Mobile"]);
                        $output .= '
                        <td style="background-color:orange"><i>MOBILE</i></td>
                        <td style="background-color:orange">'.$arr[$i]["Mobile"].'</td>
                    </tr>
                    <tr>
                        <td style="background-color:red"><i>NAME</i></td>
                        <td style="background-color:yellow">'.$arr[$i]["NAME"].'</td>
                    </tr>
                    <tr>
                        <td style="background-color:red"><i>CNIC</i></td>
                        <td style="background-color:yellow">'.$arr[$i]["CNIC"].'</td>
                    </tr>
                    <tr>
                        <td style="background-color:red"><i>ADDRESS</i></td>
                        <td style="background-color:yellow">'.$arr[$i]["ADDRESS"].'</td>
                    </tr>
                    ';
                    
                }
            }
        return $output;
    }
}

//done
function getTotalCoins($conn)
{
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $query = $conn->prepare("SELECT * FROM `users` where `id` = :userid LIMIT 1 ");
        $query->bindParam(':userid',$id,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    $coins = (int) $row1["coins"];
                    return $coins;
                }
            }
        }
    }
}

//done
function getUserMessage($conn)
{
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $query = $conn->prepare("SELECT * FROM `users` where `id` = :userid LIMIT 1 ");
        $query->bindParam(':userid',$id,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    return ucfirst(htmlentities($row1["message"]));
                }
            }
        }
    }
}

//done
function checkSpecialAccess($conn)
{
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $query = $conn->prepare("SELECT * FROM `users` where `id` = :userid LIMIT 1 ");
        $query->bindParam(':userid',$id,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    if( strval($row1["special_access"]) == "1")
                    {
                        return true;
                    }else { return false; } 
                }
            }
        }
    }
}

//done
function canUserShareCoins($conn)
{
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $query = $conn->prepare("SELECT * FROM `users` where `id` = :userid LIMIT 1 ");
        $query->bindParam(':userid',$id,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    if($row1["can_share"] == "yes")
                    {
                        return true;
                    }else { return false; } 
                }
            }
        }
    }
}

//done
function deleteCoins($conn, $quantity, $id , $delete_all)
{
    if( $id != NULL)
    {
        $query = $conn->prepare("SELECT * FROM `users` where `id` = :userid LIMIT 1 ");
        $query->bindParam(':userid',$id,PDO::PARAM_STR);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    $coins = (int) $row1["coins"];
                    if( ($coins >= $quantity) )
                    {
                        $coins = $coins-$quantity;
                        $query1 = $conn->prepare("UPDATE `users` SET coins = :coins WHERE `id` =:userid ");
                        $query1->bindParam(':userid',$id,PDO::PARAM_INT);
                        $query1->bindParam(':coins',$coins,PDO::PARAM_INT);
                        $query1->execute();
                        if($query1->rowCount() > 0)
                        {
                            return true;
                        }
                    }else if($delete_all)
                    {
                         $coins = (int)$coins/$quantity;
                        $query1 = $conn->prepare("UPDATE `users` SET coins = :coins WHERE `id` =:userid ");
                        $query1->bindParam(':userid',$id,PDO::PARAM_INT);
                        $query1->bindParam(':coins',$coins,PDO::PARAM_INT);
                        $query1->execute();
                        if($query1->rowCount() > 0)
                        {
                            return true;
                        }
                    }
                    else 
                    {
                        return false;
                    }
                }
            }
        }
    }
}

//done
function shareCoins($conn,$username,$quantity)
{
    if(checkSpecialAccess($conn) == true)
    {
         return '<div class="alert alert-danger">You cannot share coins because you have special account</div>';
    }else if( canUserShareCoins($conn) == false)
    {
         return '<div class="alert alert-danger">You cannot share coins because admin have blocked you.</div>';
    }
    else if($quantity > 0)
    {
        if(getTotalCoins($conn) >= ($quantity+1))
        {
            $query = $conn->prepare("SELECT * FROM `users` where `username` = :user LIMIT 1 ");
            $query->bindParam(':user',$username,PDO::PARAM_STR);
            $query->execute();
            if($query->rowCount() > 0)
            {
                $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
                if($rows1)
                {
                    foreach ($rows1 as $row1) 
                    {
                        $user_id = $row1["id"];
                        $coins = (int) $row1["coins"];
                        $coins = $coins + $quantity;
                        $query1 = $conn->prepare("UPDATE `users` SET `coins` = :coins WHERE `username`=:user ");
                        $query1->bindParam(':coins',$coins,PDO::PARAM_STR);
                        $query1->bindParam(':user',$username,PDO::PARAM_STR);
                        $query1->execute();
                        if($query1->rowCount() > 0)
                        {
                            deleteCoins($conn, $quantity+1 , $_SESSION["id"] ,false);
                            insertTransaction($conn, $user_id,$quantity+1);
                            return '<div class="alert alert-success">Coins Transferred Successfully</div>';
                        }
                        else
                        {
                             return '<div class="alert alert-danger">System Error. Unable to share Coins</div>';
                        }
                    }
                }
            }  else
            {
                 return '<div class="alert alert-danger">Username Does not exist</div>';
            }
        }else
        {
            return '<div class="alert alert-danger">Your Account Does not have required Coins to Share.</div>';
        }
    }else if($quantity < 0) 
    {
          return '<div class="alert alert-danger">Please Enter a positive number.</div>';
    }
}


// //done
function fetchKarachiVehicleRecord()
{
        try
        {
          $conn = new PDO("mysql:host=$dbServer;dbname=$dbName", $dbUser, $dbPass);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } 
        catch(PDOException $e) 
        {
          echo "Connection failed: " . $e->getMessage();
        }

        $arr = array();
        $tbr = array();
        $number = trim($_POST["number"] , ' ');
        $query = $conn->prepare("SELECT * FROM `2wr_1950_2017` WHERE `regno`=:reg OR `cnic`=:cnic ");
        $query->bindParam(':reg',$number,PDO::PARAM_STR);
        $query->bindParam(':cnic',$number,PDO::PARAM_STR);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows)
            {
                foreach ($rows as $row) 
                {
                    array_push($arr,$row);
                    unset($row);
                }
            }
            
            $table = $conn->query("SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`=$dbName AND `TABLE_NAME`='2wr_1950_2017'");
            if($table->rowCount() > 0)
            {
                $rows = $query->fetchAll(PDO::FETCH_ASSOC);
                if($rows)
                {
                    foreach ($rows as $row) 
                    {
                        array_push($tbr,$row);
                        unset($row);
                    }
                }
            }
        }else
        {
            $query = $conn->prepare("SELECT * FROM `4w_1950_2017` WHERE `regno`=:reg OR `cnic`=:num ");
            $query->bindParam(':reg',$number,PDO::PARAM_STR);
            $query->bindParam(':cnic',$number,PDO::PARAM_STR);
            $query->execute();
            if($query->rowCount() > 0)
            {
                $rows = $query->fetchAll(PDO::FETCH_ASSOC);
                if($rows)
                {
                    foreach ($rows as $row) 
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                }
                $table = $conn->query("SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`=$dbName AND `TABLE_NAME`='4w_1950_2017'");
                if($table->rowCount() > 0)
                {
                    $rows = $query->fetchAll(PDO::FETCH_ASSOC);
                    if($rows)
                    {
                        foreach ($rows as $row) 
                        {
                            array_push($tbr,$row);
                            unset($row);
                        }
                    }
                }
            }
        }
    
        
      if( (getTotalCoins($conn) == 0) && (checkSpecialAccess($conn) == false) )
        {
            return '
            <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
        }
        else if( (checkSpecialAccess($conn) == true) || (getTotalCoins($conn) > 0) )
        {
            $output = '';
            if(count($arr) > 0)
            {
            
                for($i = 0;$i < count($arr[0]);$i++)
                {
                    if( strtolower($tbr[0][$i]) == "id" )
                    {
                        continue;
                    }
                    $output .= $tbr[0][$i];
                    if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                    {
                         $output .= '
                            <tr  class="bg-primary text-white" style="font-weight:bold;">
                                <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                <td>'.$arr[0][$i].'</td>
                            </tr>
                            ';   
                    }else
                    {
                        $output .= '
                            <tr>
                                <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                <td>'.$arr[0][$i].'</td>
                            </tr>
                            ';
                    }
                }
                return $output;
            }
        }
}

// //done
function fetchPunjabVehicleRecord()
{
    $conn = mysqli_connect($dbServer,$dbUser,$dbPass,$dbName);
        if(count($_POST) > 0) 
        {
            $arr = array();
            $tbr = array();
            $number = trim($_POST["number"] , ' ');
            $query = mysqli_query($conn,"SELECT * FROM `Sheet 1` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
            if(mysqli_num_rows($query) > 0)
            {
                while($row = mysqli_fetch_array($query,MYSQLI_NUM))
                {
                    array_push($arr,$row);
                    unset($row);
                }
                  $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`=$dbName AND `TABLE_NAME`='Sheet 1';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
            }else
            {
                $query1 = mysqli_query($conn,"SELECT * FROM `Sheet 47` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
                if(mysqli_num_rows($query1) > 0)
                {
                    while($row = mysqli_fetch_array($query1,MYSQLI_NUM))
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                      $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`=$dbName AND `TABLE_NAME`='Sheet 47';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
                }
            }
            
          if( (getTotalCoins($conn) == 0) && (checkSpecialAccess($conn) == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess($conn) == true) || (getTotalCoins($conn) > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                
                    for($i = 0;$i < count($arr[0]);$i++)
                    {
                        if( strtolower($tbr[0][$i]) == "id" )
                        {
                            continue;
                        }
                        $output .= $tbr[0][$i];
                        if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                        {
                             $output .= '
                                <tr  class="bg-primary text-white" style="font-weight:bold;">
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';   
                        }else
                        {
                            $output .= '
                                <tr>
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';
                        }
                    }
                    
                    
                    return $output;
                }
            }
        }
}

// //done
function insertTransaction($conn, $to_user,$coins)
{
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    echo '<script>alert("sd")</script>';
    if( $id != NULL)
    {
        $query = $conn->prepare("INSERT INTO `transaction_history` (`from_user`,`to_user`,`coins`) VALUES (:userid,:to,:coins) ");
        $query->bindParam(':userid',$id,PDO::PARAM_INT);
        $query->bindParam(':to',$to_user,PDO::PARAM_STR);
        $query->bindParam(':coins',$coins,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            return true;
        }
    }
}

//done
function getUsername($conn, $userid)
{
    $query = $conn->prepare("SELECT * FROM `users` WHERE `id` = :userid ");
    $query->bindParam(':userid',$userid,PDO::PARAM_INT);
    $query->execute();
    if($query->rowCount() > 0)
    {
        $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
        if($rows1)
        {
            foreach ($rows1 as $row1) 
            {
                 return htmlentities($row1["username"]);
            }
        }
    }else
    {
        return "";
    }
}

//done
function showTransactions($conn)
{
    $output = '';
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    $username = isset($_SESSION["username"]) ? $_SESSION["username"]: NULL;
    if( $id != NULL)
    {
       
        $query = $conn->prepare("SELECT * FROM `transaction_history` WHERE `from_user` = :from OR `to_user` = :to AND DATE(sent_time) >= DATE(NOW()) - INTERVAL 30 DAY ORDER BY `sent_time` DESC ");
        $query->bindParam(':from',$id,PDO::PARAM_INT);
        $query->bindParam(':to',$id,PDO::PARAM_INT);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows)
            {
                foreach ($rows as $row) 
                {
                    if($row["from_user"] == $id)
                    {
                        $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-arrow-up" viewBox="0 0 16 16">
                          <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
                        </svg> Sent';
                    }else
                    {
                        $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-arrow-down" viewBox="0 0 16 16">
                          <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                        </svg> Received';
                    }
                    
                    $from_user = getUsername( $conn, $row["from_user"] );
                    $to_user = getUsername( $conn, $row["to_user"] );
                    
                    $time = date("H:i, d M",strtotime($row["sent_time"]));
                    $output .= '<tr>
                      <td>'.$from_user.'</td>
                      <td>'.$to_user.'</td>
                      <td>'.$row["coins"].'</td>
                      <td>'.$time.'</td>
                      <td>'.$method.'</td>
                    </tr>';
                }
                return $output;
            }
        }else
        {
            return false;
        }
    }
}

//done
function loadFamilyData($conn, $cnic)
{
    if(getTotalCoins($conn) >= 20)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://murshadtricks.com/curl.php?cnic=$cnic");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        if($server_output == 'failed')
        {
            echo 'Search Failed.';   
        }else
        {
            deleteCoins($conn, 20 , $_SESSION["id"], false);
            echo $server_output;
        }
    }else
    {
          echo '<div class="alert alert-danger">Not Enough Coins to Search. Min needed 20 coins</div>';
    }
}


//done
function publicMessage($conn)
{
    $query = $conn->query("SELECT * FROM `website` where `id` = '1' LIMIT 1 ");
    if($query->rowCount() > 0)
    {
        $rows1 = $query->fetchAll(PDO::FETCH_ASSOC);
        if($rows1)
        {
            foreach ($rows1 as $row1) 
            {
                return ucfirst(htmlentities($row["announcement"]));
            }
        }
    }
}

//done
function recoverCoins( $conn, $username )
{
    if( (strlen($username) > 0 ) )
    {
        $total_coins = 0;
        $flag = false;
        $sent_users = $sent_amount = array();
        
        $query = $conn->prepare("SELECT * , `transaction_history`.`coins` as t_coins FROM `transaction_history` INNER JOIN `users` ON `users`.`id`=`transaction_history`.`from_user` WHERE `username`=:user ");
        $query->bindParam(':user',$username,PDO::PARAM_STR);
        $query->execute();
        if($query->rowCount() > 0)
        {
            $rows = $query->fetchAll(PDO::FETCH_ASSOC);
            if($rows)
            {
                foreach ($rows as $row) 
                {
                    array_push($sent_users,$row["to_user"]);
                    array_push($sent_amount,$row["t_coins"]);
                    $total_coins += (int)$row["t_coins"]; 
                }
            }
        }
       
        for($i = 0;$i< count($sent_users);$i++)
        {
            $sent_user_id = $sent_users[$i];
            $amt = $sent_amount[$i];
            deleteCoins($conn, $amt , $sent_user_id , true);
        }
        
        $query1 = $conn->prepare("SELECT * FROM `users` WHERE `username`=:user ");
        $query1->bindParam(':user',$username,PDO::PARAM_STR);
        $query1->execute();
        if($query1->rowCount() > 0)
        {
            $rows1 = $query1->fetchAll(PDO::FETCH_ASSOC);
            if($rows1)
            {
                foreach ($rows1 as $row1) 
                {
                    $my_coins = (int)$row1["coins"];
                }
            }
        }
        
        $total_coins += $my_coins;
        $query2 = $conn->prepare("UPDATE `users` SET `coins` = :coins WHERE `username`=:user ");
        $query2->bindParam(':coins',$coins,PDO::PARAM_INT);
        $query2->bindParam(':user',$username,PDO::PARAM_STR);
        $query2->execute();
        if($query2)
        {
             return '<div class="alert alert-success">Coins for '.$username.' has been recovered successfully.</div>';
        }
    }
}
?>