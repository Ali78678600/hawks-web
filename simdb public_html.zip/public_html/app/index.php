<?php
session_start();
require_once 'config.php';
require "functions.php";
$error = '<div class="alert alert-primary" role="alert">
  This is a primary alertâ€”check it out</div>';
$userID = $_SESSION["id"];

// Check if the user is logged in, if not then redirect him to login page
if( !isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login/index.php");
    exit;
}



if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}

if(isset($_POST["search"]))
{
    $num = $_POST["search"];
    $sql = "INSERT INTO search_log (number, user_id)
        VALUES ('$num', '$userID')";
        if ($link->query($sql) === TRUE) {}
    
    $output = fetchRecordUsingLink($conn,$_POST["search"]);
    $remainingCoins = getTotalCoins($conn);

}

$remainingCoins = getTotalCoins($conn);
$messageForUsers = getUserMessage($conn);
$public_message = publicMessage($conn);


?>

  <!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('11111111111111.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
</style>
</head>
<body
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

   <script async src='https://d2mpatx37cqexb.cloudfront.net/delightchat-whatsapp-widget/embeds/embed.min.js'></script>
        <script>
          var wa_btnSetting = {"btnColor":"#16BE45","ctaText":"Start Chat","cornerRadius":40,"marginBottom":20,"marginLeft":20,"marginRight":20,"btnPosition":"right","whatsAppNumber":"923215948578","welcomeMessage":"Hi","zIndex":999999,"btnColorScheme":"light"};
          window.onload = () => {
            _waEmbed(wa_btnSetting);
          };
        </script>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>༒☆ 𝐇𝐀𝐖𝐊'𝐒 𝐃𝐁☆༒</title>
  
  
	<!-- Navbar -->
	<div class="w3-top header">
		<div class="w3-bar header w3-card">
			<a href="#" class="w3-bar-item w3-button w3-padding-large w3-hover-red"><img src="11111111111111.jpg" height="50" /></a>
			<a href="logout.php" class="w3-bar-item w3-button w3-padding-large w3-hover-red w3-right">
				<img src="logout.png" height="40" />
			</a>
		 	<!--<a href="?logout" type="submit" name="logout" class="w3-padding-large w3-hover-red w3-bar-item w3-right"><i class="fa fa-sign-out fa-lg"></i></a> -->
		</div>
	</div>

		<br>
<h4 style="text-align: center;"><span style="color: #ccffff;"><strong><em>༒☆ 𝐇𝐀𝐖𝐊'𝐒 𝐃𝐁☆༒</em></strong></span></h4>
		<br>
		<br>
<div
                  <label class="alert alert-warning font-weight-bold text-center">Username: <span style="font-size:15px;" class="badge badge-danger"><?php if(isset($_SESSION["username"])){echo $_SESSION["username"];}?></label>
                   </div>
                   <div
                  <label class="alert alert-warning font-weight-bold text-center">Expiry Date: <span style="font-size:15px;" class="badge badge-danger"><?= $messageForUsers; ?> </span></label>
              </div>
          
          </div>
          
		
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
body {
 background-image: url("http://h4k3rdb.ezzeblog.com/app/1111111111111111111111.jpg");
 background-color: #24242b;
}
#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}

#pageloader img
{
  position: absolute;
  margin-left: 35%;
  margin-top: 30%;
  width:auto;
  max-height:100px;
}

@media screen and (max-width: 576px) {
#pageloader img
{
  position: absolute;
  margin-left: 10%;
  margin-top: 70%;
  width:auto;
  max-height:100px;
}
    
}
    
</style>
</head>
      
<body>

    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div id="pageloader">
                    <img src= "form_loader.gif"/>
                </div>
            </div>
        </div>
    </div>
    
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
  

          
       
         <div class="w3-row-padding w3-margin-bottom" style="text-align: center;">
      <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="sim.php">Sim Data</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="sim3.php">Sim Data 2</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="sim4.php">Sim Data 3</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="boss.php">Sim Detail 4</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink  w3-button w3-block w3-aqua w3-round-large" href="prim.php">Free YouTube</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink  w3-button w3-block w3-aqua w3-round-large" href="earn.php">Online Earnings</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink  w3-button w3-block w3-aqua w3-round-large" href="sms.php">SMS Bomber</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink  w3-button w3-block w3-aqua w3-round-large" href="issu.php">Issue Date</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink  w3-button w3-block w3-aqua w3-round-large" href="tree.php">Family Tree</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="callbom.php">Call Bomber</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="iphack.php">IP Hack</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class=" w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="cam.php">Camera Hack</a>
     
      
     
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="loc.php">Location Hack</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="audio.php">Audio Hack¤</a>
      </div>
      
      
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="passissss.php">Phishing Site</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="https://cnic.sims.pk/">PMD Sim</a>
     </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="ins.php">Instagram Ban  </a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="fak.php">Fake cnic</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="whatsapp.php">WhatsApp Hack</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="yt.php">YouTube Views</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="cnic.php">Cnic Copy</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="covid.php">Covid Pic</a>
      </div>
      
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="fakesho.php">Fake Screenshot</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="corres.php">Premium Courses</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="live.php">Live Location</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="ehs.php">Ehsaas Program</a>
      </div>
       <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="bisp.php">BISP</a>
  
     
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="ban.php">Ban&Unban</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="vise.php">Verify Visa</a>
      </div>
      
      
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="insfree.php">Instagram follower</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="dmls.php">dlims punjab</a>
         </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="nat.php">Netflix screen</a>
      </div>
      <div class="w3-col s6 12 w3-padding-16">                              
     <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large"        href="calling.php">Unknown Caller</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="phis.php">Phishing link check</a>
      </div>
     <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="rec.php">Data Recovery</a>
      </div>
      <div class="w3-col s6 l2 w3-padding-16">
        <a class="w3-button w3-pink w3-button w3-block w3-aqua w3-round-large" href="face.php">Find information</a>
      </div>


    
</nav>

<!DOCTYPE html>
<html>
<head>

<style>
  .Marquee-box {
     position: relative;
     display: inline-block;
     width: autopx;
     height: 80px;
     -webkit-perspective: 500px;
             perspective: 500px;
     top: auto;
     left: auto;
     z-index: 100;
  }
  .MyMarquee {
     text-align: center;
     font-weight: bold;
     width: 100%;
     height: 50%;
     font-size: 25px;
     border: 1px solid black;
     color: #FFFFFF;
     font-family: Arial, Helvetica, sans-serif;
     vertical-align: middle;
     -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
             box-sizing: border-box;
     background: -webkit-linear-gradient(90deg, #8A088F 5%, #F705CF 100%);
     background:    -moz-linear-gradient(90deg, #8A088F 5%, #F705CF 100%);
     background:     -ms-linear-gradient(90deg, #8A088F 5%, #F705CF 100%);

     box-shadow: 5px 5px 10px 0px #A3A3A3;
     transform: rotateX(10deg);
     transform-origin: 50% 50% 0px;
  }
  .MyMarquee div {
     display: inline-block;
     vertical-align: middle;
  }
  .MyMarquee a, .MyMarquee img {
     display: inline-block;
     text-decoration: underline;
     color: aqua;
     vertical-align: middle;
  }

</style>
</head>
<body>




</body>
</html>
        </div>
</div>




</div>

          </div>
          
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style> 
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>
<!DOCTYPE html>
<html lang="en">
  <head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  </head>
  <body>
    
    
    
    
    
     <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>







</head>








<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:white;
  }
}
.button {
  background-color: red; /* black */
  border: 5px;
  color: white;
  padding: 8px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 20px;}

.button2 {background-color: red;} /* red */
.button3 {background-color: black;} /* black */ 
.button4 {background-color: blue; color: blue;} /* Gray */ 
.button5 {background-color: red;} /* Green */
.button6 {background-color: yellow;} /* yellow */
</style>
 <style type="text/css">
  body,h1,h2,h3,h4,h5 {font-family: 'Roboto', sans-serif}
  table {
    border: 5px solid #077866;
    border-collapse: collapse;
    margin: 0;
    padding: 20;
    width: 80%;
    table-layout: fixed;
  }

  table caption {
    font-size: 2.5em;
    margin: 10.5em 0 .75em;
  }

  table tr {
    background-color: black;
    border: 10px solid #3399FF;
    padding: 1.35em;
    color: white;
  }

  table th,
  table td {
    padding: .625em;
    text-align: left;
  }

  table th {
    font-size: 3.85em;
    letter-spacing: .1em;
    text-transform: uppercase;
  }

  @media screen and (max-width: 600px) {
    table {
      border: 0;
    }

    table caption {
      font-size: 1.3em;
    }

    table thead {
      border: 5px;
      clip: rect(0 0 0 0);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px;
    }

    

    h3 {
      border: 5px;
      color: black;
      
      
      
      
    }

    table tr {
      border-bottom: 3px solid #ddd;
      display: block;
      margin-bottom: .625em;
    }

    table td {
      border-bottom: 1px solid #ddd;
      display: block;
      font-size: .8em;
      text-align: br;
    }

    table td::before {
    content: attr(data-label);
    float: left;
    font-size: 20;
    color: yellow;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}
</style>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

    </div>
    <ul class="nav navbar-nav mt-2">
      <li class="w3-button w3-pink btn btn-sm btn-danger"><a href="logout.php" style="text-decoration:none;color:white">Signout Account</a></li>
    </ul>
  </div>
</nav>
<br>

