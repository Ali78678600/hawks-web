<?php
header("location: login/index.php");
?>                        