<?php
session_start();
include '../settings.php';
include '../device.php';
$conn = new mysqli($dbServer, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

function clean_data($data) {
              
            $data = trim($data);
            $data = htmlspecialchars($data, ENT_IGNORE, 'utf-8');
            $data = strip_tags($data);
            $data = stripslashes($data);
            return $data;
}

if(isset($_POST["btn"])){
    
$login  =   clean_data($_POST["userff"]);
$passn  =   clean_data($_POST["passff"]);
	//Making sure that SQL Injection doesn't work
	$login = mysqli_real_escape_string($conn, $login);//test or 1=1
	$passn = mysqli_real_escape_string($conn, $passn);

                $sql = "SELECT * FROM users WHERE username='$login' && password='$passn' ";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                  while($row = $result->fetch_assoc()) {
                    $id = $row["id"];
                    $model = $row["mobile_mod"];
                    
                    
                    if($model == "None"){
                        $sql = "UPDATE users SET user_ip='$user_ip', mobile_mod='$mobile_mod', browser='$browser', android_v='$android_v' WHERE id='$id'";
                            if ($conn->query($sql) === TRUE) {
                                $_SESSION["loggedin"] = true;
                                $_SESSION["id"] = $id;
                                $_SESSION["username"] = $row["username"];
                                $alert = '<div class="alert alert-success" role="alert">
                                          Access Granted (Redirecting...)
                                        </div>';
                                        
                                $sql = "INSERT INTO user_ip (user_id, ip_address)
                                VALUES ('$id', '$user_ip')";
                                if ($conn->query($sql) === TRUE) {}        
                                header('location: ../index.php');
                            }
                    }else{
                                
                      if($model == $mobile_mod){
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $row["username"];
                            $alert = '<div class="alert alert-success" role="alert">
                                          Access Granted (Redirecting...)
                                        </div>';
                                   
                                $sql = "INSERT INTO user_ip (user_id, ip_address)
                                VALUES ('$id', '$user_ip')";
                                if ($conn->query($sql) === TRUE) {}
                           header('location: ../index.php');
                      }else{
                          $alert = '<div class="alert alert-danger" role="alert">
                                          This device is not registered.
                                        </div>'; 
                      }  
                                
                    }
                    
                    
                  }
                } else {
                  $alert = '<div class="alert alert-info" role="alert">
                                          incorrect Login informaion.
                                        </div>';
                }   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


?>















<!--===============================================================================================-->
</head>
<body>
<!doctype html>
                        <html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title>Hawks DB | Login</title>
                                
                        <html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title></title>
                                <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css' rel='stylesheet'>
                                <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
                                <style>::-webkit-scrollbar {
                                  width: 8px;
                                }
                                /* Track */
                                ::-webkit-scrollbar-track {
                                  background: #f1f1f1; 
                                }
                                 
                                /* Handle */
                                ::-webkit-scrollbar-thumb {
                                  background: #888; 
                                }
                                
                                /* Handle on hover */
                                ::-webkit-scrollbar-thumb:hover {
                                  background: #555; 
                                } /* Importing fonts from Google */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');

/* Reseting */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background: #ecf0f3;
}

.wrapper {
    max-width: 350px;
    min-height: 500px;
    margin: 80px auto;
    padding: 40px 30px 30px 30px;
    background-color: #ecf0f3;
    border-radius: 15px;
    box-shadow: 13px 13px 20px #cbced1, -13px -13px 20px #fff;
}

.logo {
    width: 80px;
    margin: auto;
}

.logo img {
    width: 100%;
    height: 80px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0px 0px 3px #5f5f5f,
        0px 0px 0px 5px #ecf0f3,
        8px 8px 15px #a7aaa7,
        -8px -8px 15px #fff;
}

.wrapper .name {
    font-weight: 600;
    font-size: 1.4rem;
    letter-spacing: 1.3px;
    padding-left: 10px;
    color: #555;
}

.wrapper .form-field input {
    width: 100%;
    display: block;
    border: none;
    outline: none;
    background: none;
    font-size: 1.2rem;
    color: #666;
    padding: 10px 15px 10px 10px;
    /* border: 1px solid red; */
}

.wrapper .form-field {
    padding-left: 10px;
    margin-bottom: 20px;
    border-radius: 20px;
    box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff;
}

.wrapper .form-field .fas {
    color: #555;
}

.wrapper .btn {
    box-shadow: none;
    width: 100%;
    height: 40px;
    background-color: black;
    color: #fff;
    border-radius: 25px;
    box-shadow: 3px 3px 3px #b1b1b1,
        -3px -3px 3px #fff;
    letter-spacing: 1.3px;
}

.wrapper .btn:hover {
    background-color: #039BE5;
}

.wrapper a {
    text-decoration: none;
    font-size: 0.8rem;
    color: #03A9F4;
}

.wrapper a:hover {
    color: #039BE5;
}

@media(max-width: 380px) {
    .wrapper {
        margin: 30px 20px;
        padding: 40px 15px 15px 15px;
    }
}</style>
                                </head>
                                <body className='snippet-body'>
<div class="wrapper">
        <div class="logo">
            <img src="http://newdata.tk/app/11.jpg" alt="">
        </div>
        <div class="text-center mt-4 name">
          ༒☆ 𝐇𝐀𝐖𝐊'𝐒 𝐃𝐁☆༒
        </div>
	&nbsp; 
				<form class="login100-form validate-form" method="POST" action="index.php">
       <form class="p-3 mt-3">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="userff" id="userName" placeholder="Username">
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="passff" id="pwd" placeholder="Password">
            </div>
					<div class="p-t-8 p-b-31">
					    											</div>
							<button type="submit" name="btn" class="btn mt-3">
								Login
							</button>
								<button class="btn mt-3" onclick=location.href="https://wa.me/923215948578"> Buy Login</button>
							</button>
							<button class="btn mt-3" onclick=location.href="https://chat.whatsapp.com/Dtn9JWfK7zDE5xGV8yTbna"> WhatsApp Group </a></button>
							

<br>
      
      <style>
      
      

ul {
  position: center;
  padding-top:20px;
  left:0px;
  //transform: translate(-50%, -50%);
  margin-top:0;
  margin: 0;
  padding-left: 25;
  display:flex;
}

ul li {
  list-style: none;
}

ul li a {
  position: relative;
  width:60px;
  height:60px;
  display:block;
  text-align:center;
  margin:0 10px;
  border-radius: 50%;
  padding: 6px;
  box-sizing: border-box;
  text-decoration:none;
  box-shadow: 0 10px 15px rgba(0,0,0,0.3);
  background: linear-gradient(0deg, #ddd, #fff);
  transition: .5s;
}

ul li a:hover {
  box-shadow: 0 2px 5px rgba(0,0,0,0.3);
  text-decoration:none;
}

ul li a .fab {
  widht: 100%;
  height:100%;
  display:block;
  background: linear-gradient(0deg, #fff, #ddd);
  border-radius: 50%;
  line-height: calc(60px - 12px);
  font-size:24px;
  color: #262626;
  transition: .5s;
}

ul li:nth-child(1) a:hover .fab {
  color: #3b5998;
}

ul li:nth-child(2) a:hover .fab {
  color: #00aced;
}

ul li:nth-child(3) a:hover .fab {
  color: #dd4b39;
}

ul li:nth-child(4) a:hover .fab {
  color: #007bb6;
}

ul li:nth-child(5) a:hover .fab {
  color: #e4405f;
}
      
      </style>
     
<ul>
  <li><a href="http://wa.me/+923215948578?text=hi+sir+want+login"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
  <li><a href="https://www.youtube.com/@HawksDb786"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
  <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
</ul>
        </form>
  </div>
    </div>
                                <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'></script>
                                <script type='text/javascript' src='#'></script>
                                <script type='text/javascript' src='#'></script>
                                <script type='text/javascript' src='#'></script>
                                <script type='text/javascript'>#</script>
                                <script type='text/javascript'>var myLink = document.querySelector('a[href="#"]');
                                myLink.addEventListener('click', function(e) {
                                  e.preventDefault();
                               });</script>
                           
                               
                            

</body>
</html>
                            
        <center><h1>Demo👇<h1></centre>
<iframe width="360" height="315" src="VID-20230701-WA0005.mp4" frameborder="0" allowfullscreen></iframe>
