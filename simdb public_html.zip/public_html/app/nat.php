<?php
session_start();
require_once 'config.php';
require "functions.php";
$error = '<div class="alert alert-primary" role="alert">
  This is a primary alert—check it out</div>';
$userID = $_SESSION["id"];

// Check if the user is logged in, if not then redirect him to login page
if( !isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login/index.php");
    exit;
}



if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}

if(isset($_POST["search"]))
{
    $num = $_POST["search"];
    $sql = "INSERT INTO search_log (number, user_id)
        VALUES ('$num', '$userID')";
        if ($link->query($sql) === TRUE) {}
    
    $output = fetchRecordUsingLink($conn,$_POST["search"]);
    $remainingCoins = getTotalCoins($conn);

}

$remainingCoins = getTotalCoins($conn);
$messageForUsers = getUserMessage($conn);
$public_message = publicMessage($conn);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Fake CNIC Maker</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 


   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
body {
 background-image: url("https://www.pngmagic.com/product_images/sky-blue-hd-background-image-for-banner.jpg");
 background-color: gray;
}
#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}
</style>
</head>
<a class="btn mt-3 btn-primary" href="http://newdata.tk/app/index.php" role="button">Back</a>
<body>

    <div>
        <br>







<div class="container col-md-6" id="cont">
 
    <div class="row d-flex justify-content-center" >
      <div class="col-md-12 ">


          


<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:black;
  }
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style> 
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>


<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Fake </title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" type="image/ico" href="https://prosimdata.com/login/example/favicon.ico">

        <link href="./bootstrap.min.css" rel="stylesheet">
        <link href="./open-iconic-bootstrap.min.css" rel="stylesheet">

        <link href="./style.css" rel="stylesheet">
        
        <!-- JavaScript Resources -->
        <script src="./jquery-2.1.3.min.js.download"></script>
        <script src="./jquery-ui.js.download"></script>
        <script src="./bootstrap.min.js.download"></script>
        <script src="./login.js.download"></script>
        
        <script>$(function(){ Login.init(); });</script>
        
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous"></head>

  

    <!-- Required meta tags -->
    
    

    <!-- Bootstrap CSS -->
    
  
  <body style="background-attachment:fixed;background-position:center;background-image:url('https://imgs1.e-droid.net/srv/imgs/gen/1725513_fondo.png?v=2');background-repeat:no-repeat;background-size:cover;background-color:yellow;" onload="load()">
    
    
    
    
    
     <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  
   
      
    
        <!-- Form Module-->
                       <!-----  <div class="toggle" id="link-logged-in"><i class="oi oi-pencil"></i>Back
                <div class="tooltip in">Click Me</div>
            </div>
           <div class="form" id="form-loggedin">    ----->
               
           
          <!-------Start ---->
           
           



	<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:white;
  }
}
.button {
  background-color: red; /* black */
  border: 5px;
  color: white;
  padding: 8px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 20px;}

.button2 {background-color: red;} /* red */
.button3 {background-color: black;} /* black */ 
.button4 {background-color: blue; color: blue;} /* Gray */ 
.button5 {background-color: red;} /* Green */
.button6 {background-color: yellow;} /* yellow */
</style>
 



<style> 
input[type=number] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>
<script type="text/javascript">
    function submitForm() {
        document.getElementById('search').submit();
    }
</script>




    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fake Screenshot | NadraDB</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>





    <!--Place your code here-->




    <div class="loader" style="display: none;">

              <!--Change the "src" to your preferred loading GIF-->
        <img src="https://media.giphy.com/media/xTk9ZvMnbIiIew7IpW/giphy.gif" alt="">
    </div>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    .loader {
        display: block;
        position: fixed;
        width: 100vw;
        height: 100vh;
        background-color: rgb(36, 36, 36);
        z-index: 9999;
        justify-content: space-around;
        align-items: center;
        display: flex;
    }

    .loader h1 {
        font-size: 4rem;
        color: #fff;
        -webkit-animation: loader-anim 3s ease-in-out infinite alternate;
        -moz-animation: loader-anim 3s ease-in-out infinite alternate;
        animation: loader-anim 3s ease-in-out infinite alternate;
    }

    @keyframes loader-anim {
    30% {
        transform: translateY(-3vh);
    }
    100% {
        transform: translateY(0);
    }
    }
</style>
<script>
var loader = document.querySelector('.loader');

//The value after the function is a 500ms delay before closing the loader
function load() {
  setTimeout(function(){loader.style.display = "none"}, 500);
}
</script>






    <!-- (A) SEARCH FORM -->
    
    <form action="" method"get"="" target="">
     
           
     <center>

<h1><font color="red">Netflix Screen</font> </h1>

      <center>
      <background="color"blue"></background="color"blue"></center><b>
      
      <p>
<input type="button" class="btn btn-dark" value="Refresh" onclick="location.href = '#'">
</p>

</b></b></center></form><b><b>

 <center>




  
    <span style="font-style:bold;text-decoration:">
 <div class="container" style="margin-top:20px;">
		 <div class="card">
		 	<center><div class="card-dark bg-danger text-green" style="background-color: black; color: #FFFFFF; font-size: 17px; font-family: arial; border: solid 5px blue">Extension Link </div></center><b>
		</div>
			<center>
      <p><div>&nbsp;
<input type="button" class="btn btn-dark" value="Download" onclick="location.href = '//chrome.google.com/webstore/detail/cookie-editor/hlkenndednhfkekhgcdicdfddnkalmdm?hl=en-GB'">
</p>
			<center><div class="card-dark bg-danger text-green" style="background-color: black; color: #FFFFFF; font-size: 17px; font-family: arial; border: solid 5px blue">Cookie Converter </div></center><b>
		</div>
		<center>
      <p><div>&nbsp;
<input type="button" class="btn btn-dark" value="Go" onclick="location.href = '//accovod.com/cookieConverter/'">
</p>
    
     <center><div class="card-dark bg-danger text-green" style="background-color: black; color: #FFFFFF; font-size: 17px; font-family: arial; border: solid 5px blue">Netflix_Cookies_by_jackson</div></center><b>
      <center>
          <p><div>&nbsp;
      <input type="button" class="btn btn-dark" value="Download" onclick="location.href = '//www.mediafire.com/file/reirnrlmjgea1ic/Netflix+Cookies+by+jackson.rar/file'">
</p>
          &nbsp;
      <center>
      </p>
    
     <center><div class="card-dark bg-danger text-green" style="background-color: black; color: #FFFFFF; font-size: 17px; font-family: arial; border: solid 5px blue">Video Play</div></center><b>
      <center>
          <p><div>&nbsp;
      <input type="button" class="btn btn-dark" value="Play" onclick="location.href = '//puckered-result.000webhostapp.com/new/VID_20230531_152006.mp4'">
</p>
          &nbsp;
      <center>
      <background="color"blue"></background="color"blue"></center></b></center></b></b></b></div><table id="iframe2">


               
       
               
  


<!---loader icon---->
<style>
    .button {
  position: relative;
  padding: 8px 16px;
  background: red;
  border: none;
  outline: none;
  border-radius: 2px;
  cursor: pointer;
}

.button:active {
  background: #007a63;
}

.button__text {
  font: bold 20px "Quicksand", san-serif;
  color: #ffffff;
  transition: all 0.2s;
}

.button--loading .button__text {
  visibility: hidden;
  opacity: 0;
}

.button--loading::after {
  content: "";
  position: absolute;
  width: 16px;
  height: 16px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  border: 4px solid transparent;
  border-top-color: #ffffff;
  border-radius: 50%;
  animation: button-loading-spinner 1s ease infinite;
}

@keyframes button-loading-spinner {
  from {
    transform: rotate(0turn);
  }

  to {
    transform: rotate(1turn);
  }
}

</style>

<script>
     const btn = document.querySelector(".button");

 btn.classList.add("button--loading");
 btn.classList.remove("button--loading");

</script>



<!---loader icon end---->
  
            <!-------end ---->
           
            
            
            
            
            
            
            
                    
        </table></span></b><b><b><b>

    </b></b></b></b></body></html>