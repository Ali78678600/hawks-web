<?php
session_start();
require_once 'config.php';
require "functions.php";
$error = '<div class="alert alert-primary" role="alert">
  This is a primary alert—check it out</div>';
$userID = $_SESSION["id"];

// Check if the user is logged in, if not then redirect him to login page
if( !isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login/index.php");
    exit;
}



if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}

if(isset($_POST["search"]))
{
    $num = $_POST["search"];
    $sql = "INSERT INTO search_log (number, user_id)
        VALUES ('$num', '$userID')";
        if ($link->query($sql) === TRUE) {}
    
    $output = fetchRecordUsingLink($conn,$_POST["search"]);
    $remainingCoins = getTotalCoins($conn);

}

$remainingCoins = getTotalCoins($conn);
$messageForUsers = getUserMessage($conn);
$public_message = publicMessage($conn);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Fake CNIC Maker</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 


   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
body {
 background-image: url("https://www.pngmagic.com/product_images/sky-blue-hd-background-image-for-banner.jpg");
 background-color: gray;
}
#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}
</style>
</head>
<a class="btn mt-3 btn-primary" href="http://newdata.tk/app/index.php" role="button">Back</a>
<body>

    <div>
        <br>







<div class="container col-md-6" id="cont">
 
    <div class="row d-flex justify-content-center" >
      <div class="col-md-12 ">


          


<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:black;
  }
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style> 
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>


<!DOCTYPE html>
<html lang="en">
<head>
  

<style>
body {
 background-image: url("https://www.pngmagic.com/product_images/sky-blue-hd-background-image-for-banner.jpg");
 background-color: gray;
}
#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}
</style>
</head>

<body>

    <div>
        <br>

</nav>






<div class="container col-md-6" id="cont">
 
    <div class="row d-flex justify-content-center" >
      <div class="col-md-12 ">


          


<style>
 body{
  background-color: black; /* black */
 }
  h3{
  color:black;
  }
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style> 
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
</style>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p style="text-align: center;"><span style="color: #ff0000;">Data Recovery </span> </p>
<p style="text-align: center;"></p>
<p style="text-align: center;">السلام علیکم نیچے آپ کو ایپلیکیشن ڈاؤن لوڈ لنک ملے گا آپ نے وہیں سے اپلیکیشن کو ڈاؤن لوڈ کر لینا ہے اور اگر آپ کو سمجھ نہ لگے تو ویڈیو دیکھ لی نیچے ٹول ہے</p>
<p style="text-align: center;">👇</p>
<p style="text-align: center;"><a href="https://www.mediafire.com/file/ecq827px94txm1c/Data_Recovery.apk/file">Apk Download</a></p>
<p style="text-align: center;">👇</p>
<p style="text-align: center;"><a href="https://youtu.be/C4O3UMBiaG8">Tutorial video</a></p>
<p style="text-align: center;"></p>
</body>
</html>