<?php 
$dbServer   =   'localhost';
$dbUser     =   'newdatat_hots1';
$dbPass      =   'Asad1234@asad1234@';
$dbName     =   'newdatat_hots1';
?>