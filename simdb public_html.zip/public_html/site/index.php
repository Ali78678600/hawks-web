<?php

//print_r($_SERVER);die();

$sitepad['db_name'] = 'newdatat_spad123';
$sitepad['db_user'] = 'newdatat_spad123';
$sitepad['db_pass'] = '.W.Ztf(Z0b';
$sitepad['db_host'] = 'localhost';
$sitepad['db_table_prefix'] = 'vT76zl8_';
$sitepad['charset'] = 'utf8mb4';
$sitepad['collate'] = 'utf8mb4_unicode_ci';
$sitepad['serving_url'] = 'newdata.tk/site';// URL without protocol but with directory as well
$sitepad['url'] = 'https://newdata.tk/site';
$sitepad['relativeurl'] = '/site';
$sitepad['.sitepad'] = '/home/newdatat';
$sitepad['sitepad_plugin_path'] = '/usr/local/sitepad';
$sitepad['editor_path'] = '/usr/local/sitepad/editor';
$sitepad['path'] = dirname(__FILE__);
$sitepad['AUTH_KEY'] = 'sxL6LVWiIEG931mXNsQ4UR9xpfR48qnPT8do5ZpGQvSMGmZeGY4jhT6a9bMgnYVJ';
$sitepad['SECURE_AUTH_KEY'] = 'H6otIHFsJQDgzZeFN4A1sjLST8EFb8ies74Rn2F4HAotDkoZfP8KDI6C6LCvq26c';
$sitepad['LOGGED_IN_KEY'] = 'SdMEZL5x4nD8cbKyzKbTQ1cjAjV1Xu860M4deXGKjcUbFippxLzq7fzQVZ1rhCJc';
$sitepad['NONCE_KEY'] = 'wMSqMJikBF15mkKdchga43z3vxobcYwbPvQu9IYzW46HFXS2nvlmMzJUzvEyzVZF';
$sitepad['AUTH_SALT'] = 'Sg1rYRPYF0116XM2TshnOj8zO6kuQoYD8Fu4zUMgjlXAvEwUz4DslWYj65Kxlwd5';
$sitepad['SECURE_AUTH_SALT'] = '5Jevbqq8chf3uN30zxjr8dA0JW7f4m7VsYe5AMMQE0NyJxqtazBRI5ja6nnNriAf';
$sitepad['LOGGED_IN_SALT'] = 'NaxWcLdaGNC2okGZBrXhTE7ii5wHw5RXm0Hetvhv4Z13PbU6E8oHt18qA1Ne32PJ';
$sitepad['NONCE_SALT'] = '1cWn5v96TTwjxwTNFF9HjYrTpW4sns2n92lDUaYEu24c9Vt6nqEu78fNVxbaa1mC';

if(!include_once($sitepad['editor_path'].'/site-inc/bootstrap.php')){
	die('Could not include the bootstrap.php. One of the reasons could be open_basedir restriction !');
}

